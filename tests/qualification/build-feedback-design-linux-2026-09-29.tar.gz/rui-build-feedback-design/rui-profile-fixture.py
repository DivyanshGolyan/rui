import collections
import pathlib
import runpy
import sys
import time

target = pathlib.Path(sys.argv[1]).resolve()
sys.argv = sys.argv[1:]
sys.path.insert(0, str(target.parent))
starts = {}
totals = collections.defaultdict(float)
counts = collections.Counter()

def profile(frame, event, arg):
    path = pathlib.Path(frame.f_code.co_filename)
    if path.parent != target.parent:
        return
    if event == 'call':
        starts[frame] = time.monotonic()
    elif event == 'return' and frame in starts:
        elapsed = time.monotonic() - starts.pop(frame)
        caller = frame.f_back
        label = str(frame.f_locals.get('description', '')) if frame.f_code.co_name == 'wait_for' else ''
        key = (path.name, frame.f_code.co_name, caller.f_lineno if caller else 0, label)
        totals[key] += elapsed
        counts[key] += 1

start = time.monotonic()
sys.setprofile(profile)
try:
    runpy.run_path(str(target), run_name='__main__')
finally:
    sys.setprofile(None)
    print(f'PROFILE wall={time.monotonic()-start:.3f}', file=sys.stderr)
    for key, elapsed in sorted(totals.items(), key=lambda item: -item[1])[:65]:
        print(f'PROFILE {elapsed:.3f}s {counts[key]}x {key}', file=sys.stderr)
