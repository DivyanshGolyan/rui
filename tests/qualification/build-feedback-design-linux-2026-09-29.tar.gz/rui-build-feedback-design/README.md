# Verification-design timing evidence

Candidate source: 7e2b0eae631d795f17179410531b0c9fa7f899dc.
Linux x86-64 Amp orb, four reported CPUs, Zig 0.16.0.
The source was committed during the first final rebuild run; source/build/test
inputs stayed unchanged through the final timing sequence. Documentation follows.

Final commands ran sequentially without other compilation or test workloads:

```
/usr/bin/time -f 'wall=%e user=%U system=%S maxrss_kb=%M' zig build check-full --summary all
/usr/bin/time -f 'wall=%e user=%U system=%S maxrss_kb=%M' zig build check --summary all
/usr/bin/time -f 'wall=%e user=%U system=%S maxrss_kb=%M' zig build check-full --summary all
/usr/bin/time -f 'wall=%e user=%U system=%S maxrss_kb=%M' zig build admission-debug-integration --summary all
```

The first command includes changed native-test/Debug/ReleaseSmall recompilation;
ReleaseSafe had already rebuilt for the focused control fixture. The next three
used warm compilation caches. These are single observations, not medians, a
compiler-speedup benchmark, or empty-cache qualification.

Earlier `profile-*` files locate fixture costs before replacement; their profiling
overhead and intermediate source state make them explanatory, not final gate
comparisons. `gated-focused` and `fixed-control` record intermediate/final focused
control and Bash runs; `fixed-human` is the final human fixture. `second-check-*`
logs include the intermediate serial pass and parallel Action-prompt failure.

The FIFO probe is run from the repository root:

```
python3 rui-fifo-probe.py /absolute/path/to/rui
```

For the negative control, use a disposable copy of the candidate, set NONBLOCK
to false in server.waitAtTestGate, rebuild the ReleaseSafe CLI, then run the probe
with `--expect-blocked`. The recorded red used the intermediate blocking-open
binary; its checksum is included. The intended failure is the terminal-result
assertion after a no-writer FIFO, not setup or a timeout while opening the fixture.
An initial missing Python import failed setup and is retained separately; after
fixing that import the old binary went red at the intended assertion.

The supplied-clock Bash test was also checked with >= changed to > in the cutoff
comparison: exact-deadline closure failed, and the restored test passed. That
subagent run has no separate raw log in this archive; the final native suite
includes the restored test. It is not a native elapsed-time watchdog measurement.

Final gates keep one explicit native long-duration skip. The prior PR evidence
archive owns the real 61-second test, 1,000-cycle evaluator churn and empty-cache
build observations; those were not repeated on this candidate. No Mac runtime
or full UX-stack requalification was run for this second pass.
