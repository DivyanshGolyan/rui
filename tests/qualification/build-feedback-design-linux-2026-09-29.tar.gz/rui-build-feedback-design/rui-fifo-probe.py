"""Run from repo root: python3 PROBE.py RUI [--expect-blocked]."""
import pathlib
import sys
import tempfile

binary = str(pathlib.Path(sys.argv[1]).resolve())
expect_blocked = sys.argv[2:] == ["--expect-blocked"]
sys.path.insert(0, str(pathlib.Path("tests/integration").resolve()))
sys.argv = ["control_integration.py", binary]
import control_integration as fixture

with tempfile.TemporaryDirectory(prefix="rui-fifo-probe-") as directory:
    try:
        fixture.prove_sealed_interruption_and_cleanup(pathlib.Path(directory))
    except AssertionError as error:
        assert expect_blocked and "settlement gate with no writer" in str(error), error
        print("EXPECTED RED on blocking-open binary:", error)
    else:
        assert not expect_blocked, "old gate unexpectedly completed"
        print("PASS: held settlement, cleanup and no-writer gate")
