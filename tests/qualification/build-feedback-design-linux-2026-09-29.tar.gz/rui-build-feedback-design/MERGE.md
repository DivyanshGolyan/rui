# Verification after syncing main

The PR was synchronized with origin/main 8a328ea via merge 5995e22; the only
conflict was preserving both Host-status integration and the Debug smoke mode
in check.sh. Source candidate after a fixture correction is
c81d1a886b56e2415bf365787e5b134ce58c01f3 (see merged-source-sha256.txt).

The merged serial run passed in 245.07 seconds including recompilation.
Its parallel run failed at Host-status response classification. Fake peers
received a request with one recv before replying and closing, although the
client writes headers and body separately. Request consumption had no framing
guarantee. Peers now consume the bounded complete request before responding.
The exact syscall outcome of the original failure was not traced; an unread
body/early close can turn this into transport failure rather than the intended
response classification. A fragmented-request counterexample rejects the old
single-recv behavior at its body assertion. Production classification and
deadlines were not changed.

Final commands, sequential with warmed compilation caches:

| Command | Wall | Outcome |
| --- | ---: | --- |
| zig build host-status-integration --summary all | 3.36 s | 6/6 steps |
| zig build check --summary all | 78.92 s | 20/20 steps, 283 native passes, 1 documented skip |
| zig build check-full --summary all | 176.81 s | 23/23 steps, 283 native passes, 1 documented skip |
| zig build admission-debug-integration --summary all | 22.79 s | 5/5 steps |

All commands used /usr/bin/time; complete output is retained. The added Host-status
suite was absent from the original baseline, so these are expanded-suite totals,
not the matched-suite timing comparison in the earlier README. No competing test
or compilation workloads ran during these commands. Mac verification is separate.
