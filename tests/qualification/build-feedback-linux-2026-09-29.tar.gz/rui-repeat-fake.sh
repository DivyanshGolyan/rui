#!/bin/sh
read -r count < /tmp/rui-repeat-counter
count=$((count + 1))
printf '%s\n' "$count" > /tmp/rui-repeat-counter
value=5
if test -f /tmp/rui-repeat-corrupt && test "$count" -eq 2; then
    value=6
fi
printf '\001\000\000\000%s\000\000\000\000' "$value"
