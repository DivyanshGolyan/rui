#!/bin/bash
set -euo pipefail
root=/tmp/rui-cold-source
local_cache=/tmp/rui-cold-local
global_cache=/tmp/rui-cold-global
downloads=/tmp/rui-cold-downloads
mkdir -p "$local_cache/tmp" "$global_cache/tmp" "$downloads"
test ! -e "$root/zig-pkg"
python3 - "$root/build.zig.zon" <<'PY' > /tmp/rui-cold-dependencies
import pathlib, re, sys
dependencies = re.findall(r'\.url = "([^"]+)".*?\.hash = "([^"]+)"', pathlib.Path(sys.argv[1]).read_text(), re.S)
assert len(dependencies) == 6
for url, digest in sorted(dependencies, key=lambda pair: 'openssl' not in pair[0]):
    print(url, digest)
PY
while read -r url expected; do
    archive="$downloads/${url##*/}"
    curl --fail --location --retry 3 --silent --show-error "$url" --output "$archive"
    actual=$(zig fetch --global-cache-dir "$global_cache" "$archive")
    test "$actual" = "$expected"
    printf 'verified %s %s\n' "${url##*/}" "$actual"
done < /tmp/rui-cold-dependencies
zig build --cache-dir "$local_cache" --global-cache-dir "$global_cache" --fetch=all
/usr/bin/time -f 'wall=%e user=%U system=%S maxrss_kb=%M' zig build --cache-dir "$local_cache" --global-cache-dir "$global_cache" --summary all
