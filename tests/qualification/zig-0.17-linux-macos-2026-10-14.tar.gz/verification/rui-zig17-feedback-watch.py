import hashlib
import json
import os
from pathlib import Path
import selectors
import signal
import subprocess
import time

source = Path('src/cli.zig')
log = open('/tmp/rui-zig17-feedback-watch.log', 'wb')
process = subprocess.Popen([
    '/home/user/.local/opt/zig-0.17.0/zig', 'build', '-Doptimize=Debug',
    '-fincremental', '--watch', '--seed=0', '--summary', 'all', '-j2',
], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
selector = selectors.DefaultSelector()
selector.register(process.stdout, selectors.EVENT_READ)
previous = hashlib.sha256(source.read_bytes()).hexdigest()
pending = None
buffer = b''
rows = []
started = time.monotonic()
try:
    while len(rows) < 3:
        if time.monotonic() - started > 180:
            raise TimeoutError('bounded watch measurement incomplete')
        current = hashlib.sha256(source.read_bytes()).hexdigest()
        if current != previous:
            pending = time.monotonic()
            previous = current
        for key, _ in selector.select(0.005):
            data = os.read(key.fileobj.fileno(), 65536)
            if not data:
                raise RuntimeError(f'watch exited: {process.poll()}')
            log.write(data)
            log.flush()
            buffer += data
            while b'\n' in buffer:
                line, buffer = buffer.split(b'\n', 1)
                if b'Build Summary:' not in line:
                    continue
                if b'38/38 steps succeeded' not in line:
                    raise RuntimeError(f'failed summary: {line!r}')
                help_run = subprocess.run(['zig-out/bin/rui', '--help'], capture_output=True, check=True)
                heading = help_run.stdout.splitlines()[0].decode()
                expected_heading = source.read_text().split('const usage_text =\n')[1].splitlines()[0].strip()[2:]
                assert heading == expected_heading
                if pending is None:
                    print('watch_ready=' + heading, flush=True)
                else:
                    rows.append(dict(cycle=len(rows) + 1, seconds=time.monotonic() - pending,
                                     heading=heading, source_sha256=current,
                                     binary_sha256=hashlib.sha256(Path('zig-out/bin/rui').read_bytes()).hexdigest()))
                    print(json.dumps(rows[-1]), flush=True)
                    pending = None
    Path('/tmp/rui-zig17-feedback-watch.json').write_text(json.dumps(rows, indent=2) + '\n')
finally:
    process.send_signal(signal.SIGINT)
    try:
        process.wait(timeout=15)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait()
    selector.close()
    log.close()
    print('watch_stopped=' + str(process.returncode), flush=True)
