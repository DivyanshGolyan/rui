#!/usr/bin/env python3
"""Compare qualified runtime inputs with the final tracked PR tree."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

manifest = Path(sys.argv[1])
root = Path(sys.argv[2]).resolve()
expected = dict(line.split("  ", 1)[::-1] for line in manifest.read_text().splitlines())
tracked = set(subprocess.check_output(
    ["git", "-C", str(root), "ls-files", "-z"]).decode().rstrip("\0").split("\0"))
missing = sorted(set(expected) - tracked)
added = sorted(tracked - set(expected))
changed = sorted(path for path, digest in expected.items()
                 if hashlib.sha256((root / path).read_bytes()).hexdigest() != digest)
evidence_path = "tests/qualification/zig-0.17-linux-macos-2026-10-14.tar.gz"
assert not missing, missing
assert set(added) <= {evidence_path}, added
assert set(changed) <= {"VERIFICATION.md", "research/build-times-sources.md"}, changed
print(json.dumps({
    "qualified_input_manifest_sha256": hashlib.sha256(manifest.read_bytes()).hexdigest(),
    "qualified_paths": len(expected),
    "tracked_paths": len(tracked),
    "changed_documentation_only": changed,
    "added_evidence_only": added,
    "missing_paths": missing,
    "production_build_test_inputs_unchanged": True,
}, indent=2))
