Zig 0.17 migration evidence, 2026-10-14

Repository: https://github.com/DivyanshGolyan/rui
Owner thread: https://ampcode.com/threads/T-01a13912-1978-7188-91dd-ab44e3a6ab4e
Native verification: https://ampcode.com/threads/T-01a13929-ab4b-7200-be2c-5fcbb6a17618

This archive separates original observations from later source revisions.
Build caches do not cache acceptance. Failed attempts remain failed attempts.

linux/rui-zig17-baseline-* contains the original migration gates.
linux/rui-zig17-corrected-* contains the corrected test-only hardening gates,
including the eight-byte Smith corpus and the bounded live fuzz campaign.
linux/rui-zig17-slice-* and other intermediate logs retain earlier attempts;
the original two-byte corpus does not establish file-window boundary coverage.
verification/source.sha256 identifies the pre-integration source tree. Its
manifest excludes this new evidence archive to avoid a self-reference.
verification/input-validation.json records the production-equivalence check.
verification/reviews.txt describes the independent read-only reviews and fixes.

linux/first-integration and verification/first-integration retain observations
at 52950c7, before main's subsequent peer-retirement fixes. No native gate ran
on that historical merged snapshot.
linux/final-integration and verification/final-integration identify executable
inputs at 13c22d43fd366e11cc8aa597ea97fca279404511, incorporating main 59df275.
Every selected Linux gate passed; native merged qualification is in progress,
not established by either nested native archive. Result-documentation and this
archive are the only later source changes; source-input validation checks that
boundary. Cold baseline evidence stays attached to its original source.

native/baseline-evidence.tar.gz has SHA256
d897a5063e678684348bb9fa51ff0a750246114b9061422c924fd9379922a739.
native/hardening-evidence.tar.gz has SHA256
40ddda39c1ef73eaaf5651baee325daf1ef3609b05e954f405025fe18e211e71.
Both were downloaded and their member checksum manifests independently reread.
The native archives retain their own commands, platform metadata, complete
source reconciliation and binary hashes. No executables, Stores, credentials
or fixture roots are included.

Stock native Mac C-linked fuzz fails to link comparison/switch sanitizer hooks
before any campaign runs. The ordinary C link and true no-C fuzz controls pass.
Seeded corpus execution is not a native live-fuzz campaign.
Linux corrected live fuzz completed 1067 runs, not exhaustive coverage.

The supported cold bootstrap is src/fetch_dependencies.sh. It imports original
native archives through a disposable save-mode manifest and verifies unchanged
pinned package hashes before fetching the full graph. Bare no-prefetch fetch,
no-save archive-cache roundtrips and obsolete CLI spellings remain failures.
Cold compiler and package caches were genuinely empty on both platforms.

Development measurements cover three distinct warm one-byte help edits and
actual executable output. They do not establish general edit latency or a
Zig 0.16 comparison. Experimental incremental/watch linking failed; no watched
edit or incremental speedup is claimed. No compiler or linker workaround was
applied. ZLS build-configuration integration is unsupported upstream.

Verify outer members after extraction with sha256sum -c SHA256SUMS. Verify each
native archive's own SHA256SUMS after extracting it into a separate directory.
Exact build commands and decisive summaries are retained in the individual
logs. Native safeguards cap Zig jobs at two and source-owned transport Make at
four without changing runtime limits or replacing candidate source.

No personal installation, remote publication, live-provider acceptance,
aggregate-memory qualification, power-loss evidence or alternate-screen UI
qualification follows from these results.
