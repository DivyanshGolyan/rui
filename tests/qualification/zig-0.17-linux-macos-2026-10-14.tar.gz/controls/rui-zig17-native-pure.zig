const std = @import("std");

test "stock no-C fuzz coverage link control" {
    try std.testing.fuzz({}, check, .{});
}

fn check(_: void, smith: *std.testing.Smith) !void {
    const value = smith.valueRangeAtMost(u8, 0, 255);
    const actual: u8 = if (value == 42) 7 else 3;
    std.mem.doNotOptimizeAway(actual);
    try std.testing.expect(actual == 7 or actual == 3);
}
