const std = @import("std");
extern fn compare(value: c_int) c_int;

test "stock fuzz coverage link control" {
    try std.testing.fuzz({}, check, .{});
}

fn check(_: void, smith: *std.testing.Smith) !void {
    const value = smith.valueRangeAtMost(u8, 0, 255);
    const expected: c_int = if (value == 42) 7 else 3;
    const actual = if (@import("builtin").link_libc) compare(value) else expected;
    try std.testing.expectEqual(expected, actual);
}
