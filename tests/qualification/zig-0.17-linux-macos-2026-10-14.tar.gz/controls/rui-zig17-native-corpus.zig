const std = @import("std");

test "Smith corpus draws exact file window paddings" {
    const Case = struct { seed: []const u8, expected: u16 };
    const cases = [_]Case{
        .{ .seed = "\xfd\x0f", .expected = 0 },
        .{ .seed = "\xfe\x0f", .expected = 0 },
        .{ .seed = "\xff\x0f", .expected = 0 },
        .{ .seed = "\x00\x10", .expected = 0 },
        .{ .seed = "\xff\x1f", .expected = 0 },
        .{ .seed = "\xfd\x0f\x00\x00\x00\x00\x00\x00", .expected = 4093 },
        .{ .seed = "\xfe\x0f\x00\x00\x00\x00\x00\x00", .expected = 4094 },
        .{ .seed = "\xff\x0f\x00\x00\x00\x00\x00\x00", .expected = 4095 },
        .{ .seed = "\x00\x10\x00\x00\x00\x00\x00\x00", .expected = 4096 },
        .{ .seed = "\xff\x1f\x00\x00\x00\x00\x00\x00", .expected = 8191 },
    };
    for (cases) |case| {
        var smith: std.testing.Smith = .{ .in = case.seed };
        const actual = smith.valueRangeAtMost(u16, 0, 8192);
        std.debug.print("seed bytes={d}, padding={d}, expected={d}\n", .{ case.seed.len, actual, case.expected });
        try std.testing.expectEqual(case.expected, actual);
    }
}
