int compare(int value) {
    if (value == 42) return 7;
    return 3;
}
