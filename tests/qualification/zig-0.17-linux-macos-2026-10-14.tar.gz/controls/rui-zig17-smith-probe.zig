const std = @import("std");

test "Smith integer corpus consumes eight bytes" {
    var truncated: std.testing.Smith = .{ .in = "\xfd\x0f" };
    try std.testing.expectEqual(@as(u16, 0), truncated.valueRangeAtMost(u16, 0, 8192));
    const seeds = .{
        "\xfd\x0f\x00\x00\x00\x00\x00\x00",
        "\xfe\x0f\x00\x00\x00\x00\x00\x00",
        "\xff\x0f\x00\x00\x00\x00\x00\x00",
        "\x00\x10\x00\x00\x00\x00\x00\x00",
        "\xff\x1f\x00\x00\x00\x00\x00\x00",
    };
    const expected = [_]u16{ 4093, 4094, 4095, 4096, 8191 };
    inline for (seeds, expected) |seed, value| {
        var smith: std.testing.Smith = .{ .in = seed };
        const padding = smith.valueRangeAtMost(u16, 0, 8192);
        try std.testing.expectEqual(value, padding);
        std.debug.print("padding={d}\n", .{padding});
    }
}
