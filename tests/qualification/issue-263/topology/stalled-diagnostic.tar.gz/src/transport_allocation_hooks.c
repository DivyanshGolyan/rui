/* Disposable diagnostic: requested bytes through curl/nghttp2 and OpenSSL hooks. */
#include <curl/curl.h>
#include <openssl/crypto.h>
#include <stddef.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

typedef union {
  max_align_t align;
  struct { size_t size; unsigned kind; } record;
} Header;

static _Atomic size_t live[2], peak[2];

static void count_change(unsigned kind, size_t old, size_t new_size) {
  size_t now;
  if (new_size >= old)
    now = atomic_fetch_add(&live[kind], new_size - old) + new_size - old;
  else
    now = atomic_fetch_sub(&live[kind], old - new_size) - (old - new_size);
  size_t high = atomic_load(&peak[kind]);
  while (now > high && !atomic_compare_exchange_weak(&peak[kind], &high, now)) {}
}

static void *allocate(size_t size, unsigned kind) {
  if (size > SIZE_MAX - sizeof(Header)) return NULL;
  Header *h = malloc(sizeof(Header) + size);
  if (!h) return NULL;
  h->record.size = size;
  h->record.kind = kind;
  count_change(kind, 0, size);
  return h + 1;
}

static void release(void *pointer) {
  if (!pointer) return;
  Header *h = (Header *)pointer - 1;
  count_change(h->record.kind, h->record.size, 0);
  free(h);
}

static void *resize(void *pointer, size_t size, unsigned kind) {
  if (!pointer) return allocate(size, kind);
  if (!size) { release(pointer); return NULL; }
  if (size > SIZE_MAX - sizeof(Header)) return NULL;
  Header *h = (Header *)pointer - 1;
  size_t old = h->record.size;
  Header *next = realloc(h, sizeof(Header) + size);
  if (!next) return NULL;
  next->record.size = size;
  count_change(kind, old, size);
  return next + 1;
}

static void *curl_alloc(size_t size) { return allocate(size, 0); }
static void *curl_resize(void *p, size_t size) { return resize(p, size, 0); }
static void *curl_zero(size_t count, size_t size) {
  if (size && count > SIZE_MAX / size) return NULL;
  size_t bytes = count * size;
  void *p = curl_alloc(bytes);
  if (p) memset(p, 0, bytes);
  return p;
}
static char *curl_copy(const char *text) {
  size_t size = strlen(text) + 1;
  char *p = curl_alloc(size);
  if (p) memcpy(p, text, size);
  return p;
}
static void *openssl_alloc(size_t size, const char *file, int line) {
  (void)file; (void)line;
  return allocate(size, 1);
}
static void *openssl_resize(void *p, size_t size, const char *file, int line) {
  (void)file; (void)line;
  return resize(p, size, 1);
}
static void openssl_release(void *p, const char *file, int line) {
  (void)file; (void)line;
  release(p);
}

/* Called once before curl/OpenSSL initialization; failure is fatal, never partial evidence. */
int rui_measure_transport_init(void) {
  if (!CRYPTO_set_mem_functions(openssl_alloc, openssl_resize, openssl_release)) return 1;
  return curl_global_init_mem(CURL_GLOBAL_DEFAULT, curl_alloc, release,
                              curl_resize, curl_copy, curl_zero) == CURLE_OK ? 0 : 2;
}

void rui_measure_transport_snapshot(size_t *curl_live, size_t *curl_peak,
                                    size_t *openssl_live, size_t *openssl_peak) {
  *curl_live = atomic_load(&live[0]);
  *curl_peak = atomic_load(&peak[0]);
  *openssl_live = atomic_load(&live[1]);
  *openssl_peak = atomic_load(&peak[1]);
}
