"""Run from the repository root with ReleaseSafe CLI and host-status actor paths."""
import os
import pathlib
import socket
import sys
import tempfile
import time

sys.path.insert(0, str(pathlib.Path.cwd() / "tests/integration"))
import host_status_integration as fixture
from host_process import HostDiagnostics, stop_process

with tempfile.TemporaryDirectory(prefix="rui-fd-oracle-") as root:
    store = pathlib.Path(root) / "store"
    os.environ["RUI_CODEX_CREDENTIAL_FILE"] = str(pathlib.Path(root) / "missing.json")
    host, fields = fixture.start(store, 3, "--codex", "--test-phase-trace")
    diagnostics = HostDiagnostics(host)
    held = socket.socket(socket.AF_UNIX)
    try:
        diagnostics.wait("lifecycle_boundary")
        assert b'"type":"host_info"' in fixture.raw_info(pathlib.Path(fields["socket"]), store.resolve())
        baseline = fixture.wait_for_descriptors(host.pid)
        held.connect(fields["socket"])
        # A partial request keeps a real accepted Host descriptor in custody.
        held.sendall(b"POST /v1/host-info ")
        deadline = time.monotonic() + 5
        while fixture.wait_for_descriptors(host.pid) == baseline:
            assert time.monotonic() < deadline, "Host did not accept the held connection"
            time.sleep(.01)
        try:
            fixture.wait_for_descriptors(host.pid, baseline, timeout=.1)
        except AssertionError as error:
            expected, observed = error.args[0]
            assert expected == baseline
            assert len(observed) == len(baseline) + 1, observed
            print("RED: exact-map drain assertion rejects held Host descriptor", len(baseline), len(observed))
        else:
            raise AssertionError("retained Host descriptor escaped the oracle")
        held.close()
        restored = fixture.wait_for_descriptors(host.pid, baseline)
        assert restored == baseline
        print("GREEN: peer close drains Host back to identical descriptor map", len(restored))
    finally:
        held.close()
        stop_process(host)
        diagnostics.close()
