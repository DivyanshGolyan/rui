#!/bin/bash
set -euo pipefail
prefix=${1:-/tmp/pr365-clean}
root=$prefix-source
local_cache=$prefix-local
global_cache=$prefix-global
downloads=$prefix-downloads
mkdir -p "$local_cache/tmp" "$global_cache/tmp" "$downloads"
test ! -e "$root/zig-pkg"
python3 - "$root/build.zig.zon" <<'PY' > "$prefix-dependencies"
import pathlib, re, sys
dependencies = re.findall(r'\.url = "([^"]+)".*?\.hash = "([^"]+)"', pathlib.Path(sys.argv[1]).read_text(), re.S)
assert len(dependencies) == 6
for url, digest in sorted(dependencies, key=lambda pair: 'openssl' not in pair[0]):
    print(url, digest)
PY
while read -r url expected; do
    archive="$downloads/${url##*/}"
    curl --fail --location --retry 3 --silent --show-error "$url" --output "$archive"
    actual=$(zig fetch --global-cache-dir "$global_cache" "$archive")
    test "$actual" = "$expected"
    printf 'verified %s %s\n' "${url##*/}" "$actual"
done < "$prefix-dependencies"
zig build --cache-dir "$local_cache" --global-cache-dir "$global_cache" --fetch=all
/usr/bin/time -f 'wall=%e user=%U system=%S maxrss_kb=%M' zig build --cache-dir "$local_cache" --global-cache-dir "$global_cache" --summary all
