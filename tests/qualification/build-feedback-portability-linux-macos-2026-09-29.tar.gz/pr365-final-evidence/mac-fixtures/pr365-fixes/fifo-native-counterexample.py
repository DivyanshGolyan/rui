import os,tempfile,threading,time,fcntl
print('macOS FIFO owner-boundary diagnostic; blocking and nonblocking read paths',flush=True)
for blocking in (True,False):
 path=tempfile.mktemp(prefix='rf365-fifo-'); os.mkfifo(path); writer=os.open(path,os.O_RDWR|os.O_NONBLOCK)
 ready=threading.Barrier(11); done=[]
 def read_gate(i):
  fd=os.open(path,os.O_RDONLY|os.O_NONBLOCK)
  try:
   try: os.read(fd,1)
   except BlockingIOError: pass
   else: raise AssertionError('reader was not held')
   if blocking: fcntl.fcntl(fd,fcntl.F_SETFL,0)
   ready.wait()
   while True:
    try: result=os.read(fd,1); break
    except BlockingIOError: time.sleep(.01)
   done.append((i,result))
  finally: os.close(fd)
 for i in range(10): threading.Thread(target=read_gate,args=(i,),daemon=True).start()
 ready.wait(); time.sleep(.1); assert not done
 os.unlink(path); os.close(writer)
 deadline=time.monotonic()+1
 while len(done)<10 and time.monotonic()<deadline: time.sleep(.01)
 print('blocking=',blocking,'held=10 returned=',len(done),'results=',done,flush=True)
 if not blocking: assert len(done)==10 and all(v==b'' for _,v in done)
print('Diagnostic settle interval is not the native integration oracle; patched native test_gate_waiting milestones establish all held readers.',flush=True)
