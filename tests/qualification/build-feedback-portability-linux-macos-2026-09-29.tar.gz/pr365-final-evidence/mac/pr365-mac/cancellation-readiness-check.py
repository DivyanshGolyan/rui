import pathlib
import subprocess
import tempfile
import time

old = '/tmp/rc365/o/c820dc71d36102a820368cf0559ec0de/rui-evaluator-boundary-test'
new = '/tmp/rc365/o/2601d462ffee0468c1d8a1cf692f79db/rui-evaluator-boundary-test'
with tempfile.TemporaryDirectory() as directory:
    root = pathlib.Path(directory)
    source = root / 'source'
    source.write_text('unused')
    marker = root / 'ready'
    fake = root / 'child'
    fake.write_text(f'#!/bin/sh\nsleep .25\n: > "{marker}"\nwhile :; do :; done\n')
    fake.chmod(0o700)
    for driver in (old, new):
        marker.unlink(missing_ok=True)
        start = time.monotonic()
        command = [driver, str(fake), str(source), 'live-cancel', '1000000']
        if driver == new:
            command.append(str(marker))
        result = subprocess.run(command, capture_output=True, timeout=7)
        print('driver', driver, 'exit', result.returncode, 'ready', marker.exists(),
              'elapsed', time.monotonic() - start, flush=True)
        assert result.returncode == 1
        assert marker.exists() == (driver == new)
    marker.unlink()
    fake.write_text(f'#!/bin/sh\nsleep .25\necho $$ > "{marker}"\n'
                    'while :; do printf "\\001\\000\\000\\000x"; done\n')
    result = subprocess.run([new, str(fake), str(source), 'output-cancel', '1000000'],
                            capture_output=True, timeout=7)
    print('output-cancel exit', result.returncode, 'ready', marker.exists(), flush=True)
    assert result.returncode == 1 and marker.exists() and result.stdout == b''
