#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>

__attribute__((noinline)) static unsigned long touch_stack(unsigned frames) {
    volatile unsigned char page[4096];
    for (unsigned i = 0; i < sizeof(page); i++) page[i] = (unsigned char)i;
    unsigned long value = frames ? touch_stack(frames - 1) : 0;
    return value + page[0] + page[4095];
}

int main(int argc, char **argv) {
    if (argc != 2) return 2;
    struct rlimit core = {0, 0}, cpu = {1, 2};
    if (setrlimit(RLIMIT_CORE, &core) || setrlimit(RLIMIT_CPU, &cpu)) return 3;
    printf("pthread stack=%zu base=%p\n", pthread_get_stacksize_np(pthread_self()),
           pthread_get_stackaddr_np(pthread_self()));
    fflush(stdout);
    printf("completed %lu\n", touch_stack((unsigned)strtoul(argv[1], NULL, 10)));
    return 0;
}
