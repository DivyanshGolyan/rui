#include <sys/resource.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>

int main(void) {
    struct rlimit core = {0, 0}, cpu = {1, 2}, stack = {1024 * 1024, 1024 * 1024};
    int resources[] = {RLIMIT_CORE, RLIMIT_CPU, RLIMIT_STACK};
    struct rlimit *limits[] = {&core, &cpu, &stack};
    const char *names[] = {"core", "cpu", "stack"};
    for (int i = 0; i < 3; i++) {
        struct rlimit before;
        getrlimit(resources[i], &before);
        errno = 0;
        int result = setrlimit(resources[i], limits[i]);
        printf("%s before=%llu/%llu requested=%llu/%llu result=%d errno=%d %s\n",
               names[i], before.rlim_cur, before.rlim_max,
               limits[i]->rlim_cur, limits[i]->rlim_max, result, errno, strerror(errno));
    }
    return 0;
}
