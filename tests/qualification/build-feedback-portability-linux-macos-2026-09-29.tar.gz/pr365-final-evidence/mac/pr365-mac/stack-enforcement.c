#include <sys/resource.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>

__attribute__((noinline)) static unsigned long touch_stack(unsigned frames) {
    volatile unsigned char page[4096];
    for (unsigned i = 0; i < sizeof(page); i++) page[i] = (unsigned char)i;
    unsigned long value = frames ? touch_stack(frames - 1) : 0;
    return value + page[0] + page[4095];
}

int main(int argc, char **argv) {
    if (argc != 2) return 2;
    struct rlimit core = {0, 0}, cpu = {1, 2}, stack = {1048576, 1048576};
    if (setrlimit(RLIMIT_CORE, &core) || setrlimit(RLIMIT_CPU, &cpu) ||
        setrlimit(RLIMIT_STACK, &stack)) {
        fprintf(stderr, "setrlimit failed: %d %s\n", errno, strerror(errno));
        return 3;
    }
    struct rlimit actual;
    getrlimit(RLIMIT_STACK, &actual);
    printf("stack soft=%llu hard=%llu; touching %s 4096-byte frames\n",
           actual.rlim_cur, actual.rlim_max, argv[1]);
    fflush(stdout);
    printf("completed %lu\n", touch_stack((unsigned)strtoul(argv[1], NULL, 10)));
    return 0;
}
