import pathlib
import resource
import shlex
import subprocess
import tempfile

here = pathlib.Path(__file__).parent
lines = (here / 'corrected-workflow-check.log').read_text().splitlines()
command = shlex.split(next(line for line in lines if 'build-exe --stack 1048576' in line))
command.remove('--listen=-')
command[command.index('--stack') + 1] = '2097152'
command.append('-femit-bin=/tmp/r365-evaluator-mismatch')
print('Mismatch build:', shlex.join(command), flush=True)
subprocess.run(command, check=True)
invocation = shlex.split(next(line for line in lines if line.startswith('python3 ')))
binary, driver = invocation[2:4]
mismatch = '/tmp/r365-evaluator-mismatch'
for executable in (binary, mismatch):
    metadata = subprocess.check_output(['otool', '-l', executable], text=True)
    stack = metadata.split('cmd LC_MAIN', 1)[1].split('Load command', 1)[0]
    print(executable, stack, flush=True)
    assert f'stacksize {1048576 if executable == binary else 2097152}' in stack

with tempfile.TemporaryDirectory() as directory:
    source = pathlib.Path(directory) / 'source'
    source.write_text('export default async function workflow() { return 5; }')
    for inherited in (False, True):
        def limits():
            if inherited:
                resource.setrlimit(resource.RLIMIT_STACK, (1048576, 1048576))
        for executable in (binary, mismatch):
            direct = subprocess.run(
                ['sh', '-c', 'exec "$1" check-prepared 3< "$2"', 'sh', executable, str(source)],
                preexec_fn=limits, capture_output=True, timeout=7)
            parent = subprocess.run([driver, executable, str(source), 'run', '67108864'],
                                    preexec_fn=limits, capture_output=True, timeout=7)
            print('inherited1MiB=', inherited, 'binary=', executable,
                  'direct=', direct.returncode, 'parent=', parent.returncode,
                  'stdout=', parent.stdout, flush=True)
            assert direct.returncode == (0 if executable == binary else 3)
            assert parent.returncode == (0 if executable == binary else 1)
            assert parent.stdout == (b'5' if executable == binary else b'')
    def low_cpu():
        resource.setrlimit(resource.RLIMIT_CPU, (1, 1))
    failed = subprocess.run(
        ['sh', '-c', 'exec "$1" check-prepared 3< "$2"', 'sh', binary, str(source)],
        preexec_fn=low_cpu, capture_output=True, timeout=7)
    print('inherited CPU hard1 direct=', failed.returncode, flush=True)
    assert failed.returncode == 3
