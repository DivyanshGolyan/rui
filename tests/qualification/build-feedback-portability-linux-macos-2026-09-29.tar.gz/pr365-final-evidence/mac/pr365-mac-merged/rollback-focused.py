import pathlib
import sys
import tempfile
import textwrap
import threading

sys.path.insert(0, str(pathlib.Path.cwd() / 'tests/integration'))
import dispatch_integration as fixture

source = pathlib.Path('tests/integration/dispatch_integration.py').read_text()
start = source.index('        # A failed Attempt commit rolls back all provenance')
end = source.index('        # The first fallible post-commit step', start)
case = textwrap.dedent(source[start:end])
endpoint = fixture.FailureEndpoint()
thread = threading.Thread(target=endpoint.serve_forever, daemon=True)
thread.start()
with tempfile.TemporaryDirectory(prefix='rui-rollback-focused-') as directory:
    state = pathlib.Path(directory)
    context = dict(vars(fixture), state=state, endpoint=endpoint,
                   url=f'http://127.0.0.1:{endpoint.server_port}/responses',
                   processes=[], rollback_milestones=None)
    try:
        exec(compile(case, 'actual-dispatch-rollback-case', 'exec'), context)
        print('actual rollback/release/restart/replay case passed', flush=True)
    except BaseException:
        milestones = context.get('rollback_milestones')
        if milestones:
            print('first rollback records:',
                  milestones.matching('attempt_admission_rolled_back')[:3], flush=True)
        print('durable state:', fixture.observe(state / 'rollback-store', 'rollback-message'), flush=True)
        print('endpoint requests:', len(endpoint.requests), flush=True)
        raise
    finally:
        endpoint.release.set()
        for process in context['processes']:
            fixture.stop_host(process)
        milestones = context.get('rollback_milestones')
        if milestones:
            milestones.close()
        endpoint.shutdown()
        endpoint.server_close()
        thread.join(timeout=3)
