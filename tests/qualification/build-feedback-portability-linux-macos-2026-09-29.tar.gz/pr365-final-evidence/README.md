# PR 365 portability and final verification evidence

Runtime/test fixes: `cc87b4e78c4ca02780c700644183962ecc183df1`.
Conflict-resolved candidate including main's Host-launch suite:
`fe6e6fc584402b9d43a23c676c71bd320d8946de`.
Rollback owner-boundary assertion: `0c5299dfdf9a45a4dfe4f5fa62906bf714673c6d`.
Final Linux descriptor oracle: `203a18fc4ec3d426b94e47bc49e558ce0cdab334`.
Repository: https://github.com/DivyanshGolyan/rui

## Provenance

- `linux/pr365-linux-final-*` belongs to cc87b4e. The rebuild run began
  before its commit, without changing build/test inputs during execution.
- `linux/pr365-linux-merged-*` belongs to fe6e6fc. The first full run includes
  compilation; files explicitly named `warm` have cached compiler outputs.
- `linux/pr365-linux-release-boundary-*` belongs to 0c5299d. Its serial
  rebuild passed; parallel checking exposed the retained Host-status FD
  snapshot failure, so the queued warm-full run was not executed unchanged.
- `linux/pr365-linux-delivery-*` belongs to 203a18f. This changes only the
  Linux Host-status descriptor oracle and its verification contract.
- Linux commands use `/usr/bin/time -f 'wall=%e user=%U system=%S maxrss_kb=%M'
  zig build STEP --summary all`, serially without competing test/build loads.
  Test-runner stderr may include `failed command` after expected injected
  errors. Final exit and Build Summary distinguish these from failed gates.
- The native exact-duration witness is skipped in routine gates and included
  in `test-full`. The evaluator's 1,000-cycle witness is `evaluator-churn`.
- `mac/pr365-mac` retains original c81d1a8 failures, actually executed
  ffc5eb7 baseline failure, diagnosis, fixes, and assembled cc87b4e-equivalent
  runs. Its README/provenance and manifests distinguish each revision.
- Comparing complete code/build/test manifests found only an old Linux
  evidence archive differed between the assembled Mac checkout and cc87b4e;
  all executable inputs were identical. Documentation intentionally differed.
- `mac-fixtures/pr365-fixes` contains the three process-fixture corrections
  and focused Mac results. The FIFO probe's short settling delay is diagnostic,
  not the native integration oracle; native first-WouldBlock milestones prove
  every inspection waiter reached the held boundary before release.
- `mac/pr365-mac-merged` contains the failed fe6e6fc parallel check, then
  corrected 0c5299d-equivalent check/check-full plus rollback mutation proof.
- `mac/pr365-mac-host-status-final` covers the final changed fixture on Mac.
  Earlier broad Mac gates predate this Linux-only oracle edit. Runtime and
  Mac-path behavior are unchanged; focused final coverage passed 6/6.
  Final Linux/Mac executable-input manifests match exactly:
  `721f66e8aff4785183dd11ebdbe2c522179f048cd7dd34105920ed2a078117b6`.
- The original Linux Host-status failure captured counts 9/10, not descriptor
  identities; its exact FD was not traced. The new oracle waits for execution
  initialization and isolated EOF before baseline capture, then requires the
  exact map after batch drain. The native held-connection probe fails with an
  extra descriptor and passes only after close. Reproduce from repo root:
  `python3 pr365-status-drain-probe.py /path/to/rui-release-safe-check /path/to/rui-host-status-test`.

## Reproduction and limits

The clean Linux exports were made using `git archive` at their named revision,
then checked against complete tracked-file SHA-256 manifests. No `zig-pkg`
existed initially; local/global caches were new. The archived clean-build
scripts download all six pinned archives with curl, hash-verify them through
`zig fetch` (OpenSSL first), fetch the complete graph, and build. The timed
build excludes download/fetch time. This does not qualify Zig's own downloader.

Mac probes and commands are retained with the logs. The published XNU source
supports the diagnosis but is not claimed byte-identical to the running kernel.
Below/above-bound page-touch probes and mismatched-stack evaluator artifacts
establish observed enforcement and fail-closed behavior, not protection after
arbitrary native-code execution. The selected Mac main stack is fixed at 1 MiB,
not tightened from inherited RLIMIT_STACK.

Warm timings are single observations, not medians, compiler speedups, or
production throughput guarantees. The original Mac baseline fails before
evaluation; it cannot supply a valid whole-suite speedup percentage. The final
merged suite adds Host-launch coverage absent from earlier measured candidates.
No live provider, power-loss, complete workflow, or resource-fleet qualification
is implied by these development gates.
