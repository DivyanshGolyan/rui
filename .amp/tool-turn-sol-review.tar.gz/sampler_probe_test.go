package main

import (
	"os"
	"sync"
	"testing"
)

func TestReviewSamplerConcurrentTUI(t *testing.T) {
	raw, err := os.CreateTemp(t.TempDir(), "samples")
	if err != nil { t.Fatal(err) }
	defer raw.Close()
	s := &toolSampler{host: os.Getpid(), records: map[string]*toolProcessRecord{}, raw: raw}
	var wait sync.WaitGroup
	wait.Add(1)
	go func() {
		defer wait.Done()
		for i := 0; i < 100000; i++ { s.setTUI(999999 + i%2) }
	}()
	for i := 0; i < 10; i++ { s.sample() }
	wait.Wait()
}
