# Tool-turn review requires corrections

Reviewer: Sol, thread T-01a16225-fe53-753b-a6b6-d9e7f8487b55. Read-only Linux cloud review on 22 October 2026.

Code candidate: `8ee27b01102908144c4db2e621121b83e5c99696`, compared with `d4f870002b1eeef370fb8f4c7aa3fd8b14343159`. Six Go files under `tests/qualification/model-output` change. Report candidate: `0684f535`, branch `perf/tool-turn-20261022`. SQLite v2 was not reviewed.

Verdict: request changes. The phase-aware request count correction is correct. The historical reductions reproduce, but the measurement program can accept false successes. No implementation, production launch, descriptor, ref, workflow, or landing changes were made.

## Spec findings

### R1, P1: terminal worker failures do not fail the run

Location: `tool_linux.go:864-880`, with `measurement/client.go:206-223`.

`WaitResult` returns any terminal result, including failure. The new caller records an unsuccessful result in `dispatch_result_example` and continues. Its final success predicate never examines that field. The provider marks `Done` when it receives the continuation, before sending the final answer. A worker can therefore deliver successful Bash outputs, fail while accepting its final model answer, and still leave the run `passed`. Only the coordinator receives a work-status check. Neither workers nor the coordinator have their exact final saved answer checked.

Smallest complete correction: require success for every original worker request, fail otherwise, and verify each Session's expected final saved answer through existing result readers. Retain the failed observation. Add one negative control where valid tool outputs precede a failed final worker result. This preserves the original request identities and requires no compatibility format.

Evidence limit: this failure sequence follows the actual predicates and existing `WaitResult` contract. I did not run a complete modified Host campaign to inject the final-answer failure. None of the 60 historical JSONs contains `dispatch_result_example`.

### R2, P1: an output for an unissued call can count as successful workload

Location: `provider/tool.go:289-328`, `tool_linux.go:920-922`.

The provider accepts any call ID with the Session prefix, stores outputs in a map, and validates only the map size. The outer check compares generated call counts rather than exact returned identities. A public-provider probe sent `tool-000-never-issued` instead of the issued workload call. The provider returned `done=1`, `workload_calls=1`, `succeeded_calls=1`, `failed_calls=0`, and `errors=[]`, with no shell markers. These facts satisfy the new run's tool-summary success predicate.

Smallest complete correction: retain or derive the exact issued call IDs and kinds, then require exactly one output for each, no duplicates or unissued IDs, and the required ordered start/end markers. Count completed workload and dispatch calls from those validated outputs. Add a regression for a same-prefix unissued ID replacing the expected output. Do not add another durable entity.

Reproducer: `provider_probe.go`, executed against the unchanged exported candidate with `go run -mod=readonly /absolute/path/provider_probe.go` from `tests/qualification`. Output is in `provider-probe.log`.

### R3, P2: barrier failures are recorded or ignored but can still pass

Location: `provider/tool.go:137-138`, `tool_linux.go:1001-1020`, and the final success predicate at `920-930`.

The shell unconditionally runs the workload after `read -t 120`, even when the read times out. The controller also returns success after its 60-second partial-parking timeout, recording only `timed_out=true`. The final predicate requires neither complete parking nor complete markers or achieved overlap.

The probe used the exact generated command with only its timeout shortened from 120 seconds to 0.05 seconds. An unreleased real FIFO timed out, yet `cat` printed `READ_WITHOUT_RELEASE` and the command exited zero. This is a failure-accounting counterexample, not a 120-second native timing pass.

Smallest complete correction: preserve a failed barrier read as failure, and classify a partial controller barrier as incomplete or failed. For a claim of N overlapping workload calls, validate the measured intervals separately. Keep natural non-barrier runs valid. Add the unreleased-FIFO negative control. All 36 historical non-strace v2 runs parked all N shells before release and reached N overlapping shell intervals, so this finding does not invalidate their recorded overlap.

## Standards and evidence findings

### R4, P2: concurrent measurement state has data races

Locations: `tool_linux.go:265-266,343`, `provider/tool_test.go:132-146`.

`setTUI` writes `s.tui` under a mutex while the sampler reads it without that mutex. A temporary Go overlay test exercised the unchanged implementation and `go test -race` reported that exact read/write race. The canonical test itself also races: `TestBarrierHoldsWorkloadUntilRelease` reads `stdout.Len()` while `os/exec` copies into the same `bytes.Buffer`.

Smallest complete correction: snapshot the sampler's mutable fields under their existing lock, and use synchronized output or file-backed observation in the barrier test. Review the analogous unlocked reads of `fact.WorkloadCalls` and `fact.CallsSentNS` after the provider releases its mutex at `provider/tool.go:350`. That analogous provider path is source-identified, not dynamically reproduced here.

Verification: both race runs failed, with full output in `race.log` and `sampler-race.log`. The latter uses `overlay.json` and `sampler_probe_test.go`, with no source-file edits. `measurement-check` does not enable the race detector and passed separately.

### R5, P2: the report calls sequential, sometimes incomplete PSS scans simultaneous samples

Locations: `.amp/tool-turn-v2/REPORT.md`, results introduction and short-lived process coverage; `tool_linux.go:272-304,321-325,1025-1036`.

Each tree sample reads processes sequentially. At read N=100 and nominal 25 ms, the three peak scans took 65.574379 ms, 11.448088 ms, and 35.654059 ms. Their sums were 67.937280 MB, 54.093824 MB, and 63.926272 MB. The median reported peak is therefore 63.926272 MB, but it is not an instantaneous or simultaneous measurement. The third peak sample had 10 PSS failures. At 200 ms, the second repeat's peak had 42 PSS failures. Failed PSS reads still increment process coverage, and the next sample starts only after scan duration plus the configured interval.

The report already disclaims exact peaks and correctly says that independent column maxima need not add to the aggregate maximum. It must additionally describe the aggregate as a sequential-scan sum, show scan-duration and PSS-read-failure coverage, and separate process identities seen from identities with successful PSS reads. For example, read N=100 at 25 ms saw all 199 shell identities but obtained nonzero PSS maxima for only 134, 131, and 147 of them. In repeat 2, 102 child identities were seen but only 99 had nonzero PSS maxima.

Smallest correction: update the reducer and report from existing raw records. No new campaign is needed for these caveats. Keep the measured sum, but do not claim it bounds the true simultaneous peak. The 3.1 MB missing-send estimate is correctly labelled an estimate, not a bound.

## Verified historical evidence

- Re-executed the v2 reducer against all 22 v1 and 38 v2 raw archives. Both outputs equal their published JSON summaries exactly.
- Independently checked every run's 409600-byte seed records, 3N provider requests, N seeds before the CPU window, and N measured requests plus N continuations inside it. At N=100, the CPU denominator is 200, not 300. `toolRequestPhases` and its asymmetric boundary test implement this correctly.
- Every run has provider `done=N`, `succeeded_calls=2N-1`, and `failed_calls=0`. These are provider observations, subject to R1 and R2's oracle limitations.
- Every raw sample's Host, Bash, and Clients columns add to its total, for both counts and PSS. Every final process record has a unique PID and start-time pair. This checks recorded deduplication, not the identity race between reading `/proc/PID/stat` and reading PSS. The collector does not revalidate that start time around its later PSS read.
- All recorded source-file hashes match the historical harness trees: v1 `95da4883`, v2 `aeef8596`. The final phase-count candidate is newer and was tested locally here, not used to rerun the campaigns. Historical binary hashes agree across runs. No product or harness executable is included in the report archives, so I did not independently hash or execute those original binaries.
- The corrected reducer pairs clone-entry timestamps, including unfinished/resumed calls, with child execve entries. It reproduces all 1632 non-negative pairs across six strace runs. This establishes the reduction of instrumented timings, not untraced latency or a formal upper bound.
- Natural v1 shell overlap and artificial v2 barrier overlap are distinct. N overlapping shell command intervals do not independently establish N simultaneous kernel read syscalls.
- Raw points support retained scratch output and separate Store/cache observations. System `Cached` cannot attribute turn growth. Store `fincore` residency is separate from process PSS. Seed file deletion does not establish global page-cache eviction.

## Fork, descriptors, and signals

`src/bash.zig:133` is a test-only fork. Production `Prepared.launch` at `src/bash.zig:246` calls `std.process.spawn` with an absolute Bash path, path cwd, ignored stdin, piped stdout and stderr, and pgid zero. Installed stock Zig 0.17.0 routes Linux to `Io.Threaded.spawnPosix` and Darwin to its spawn implementation.

In the installed Linux source, argv and environment allocation precede libc `fork`. The normal Rui child path blocks Zig cancellation and performs path conversion on the stack, `chdir`, three `dup2` calls, `setpgid`, and `execve`. Expected failures use an error-pipe write and `_exit`. Blocked cancellation makes the relevant syscall bookkeeping return before its normal atomics. I found no allocator or mutex in this normal child path.

This is a source-supported normal-path assessment, not an unconditional fork-safety proof. Zig's unexpected-errno paths can print and dump a stack in Debug. `Threaded.errnoBug` can panic in Debug. Those diagnostics are outside the minimal async-signal-safe child path. The exact report executable and its dynamic imports were unavailable, so the report's binary-import assertion was not independently checked. No forced fork-failure or inherited-lock native campaign ran here.

The installed `getDevNullFd` opens `/dev/null` read-write without CLOEXEC, and the child duplicates it to stdin without closing the original. This supports the descriptor-inheritance finding. The report's `fd-probe.txt` records fd 19 in Bash and sleep, but it is an owner transcript, not a native probe reproduced by this reviewer. The descriptor number is run-specific. SQLite's pinned Linux open path requests O_CLOEXEC. Curl's pinned socket path uses SOCK_CLOEXEC when supported. These inspected paths do not establish that no other descriptor can leak.

The child path does not reset its signal mask or ignored dispositions. Successful exec resets caught handlers while preserving ignored dispositions and the mask. An observed zero Host mask and ignored set cover that observed run, not every caller environment. Bash's own later signal changes do not describe the pre-exec child.

Pinned OpenSSL 3.6.3 exports empty fork hook functions, and its pthread `openssl_init_fork_handlers` returns success without registration. Authoritative upstream sources confirm those facts. That does not establish the absence of every other library fork interaction.

Authoritative glibc 2.36 source confirms that Linux `posix_spawn` uses CLONE_VM | CLONE_VFORK, blocks signals while preparing the child, supports explicit signal-mask and default-disposition attributes, and supports chdir, dup2, and process-group actions covering Rui's current launch options. It does not automatically close every unrelated non-CLOEXEC descriptor. A switch would still need deliberate descriptor hygiene, parent pipe/handle ownership, cleanup and exec-error handling, and native lifecycle qualification. The source comparison does not establish a speed benefit.

Source references: glibc `glibc-2.36/sysdeps/unix/sysv/linux/spawni.c`; OpenSSL `openssl-3.6.3/crypto/threads_lib.c` and `crypto/threads_pthread.c`; installed `/home/user/.local/opt/zig-0.17.0/lib/std/Io/Threaded.zig`, especially 15282-15520 and 17312-17400. Exact Zig 0.17.0 upstream revision was unavailable through the external source lookup, so that portion rests on the installed toolchain. No production launch or descriptor fix is authorized by this review.

## Checks and delivery limits

- Selector on the exact base and candidate selects only `measurement-check`, including hosted Mac selection.
- In an isolated source export, `ZIG_LOCAL_PKG_DIR=/home/user/workspace/repo/zig-pkg zig build measurement-check -j2 --summary all` exited zero: `Build Summary: 4/4 steps succeeded`. Go 1.27.1 and Zig 0.17.0 on Linux x86-64.
- `GOOS=darwin GOARCH=arm64 GOTOOLCHAIN=local go vet -mod=readonly ./model-output/...` exited zero. This is static analysis, not Mac execution.
- `GOTOOLCHAIN=local go test -count=1 -mod=readonly -race ./model-output ./model-output/provider` failed in the new barrier test. The temporary sampler overlay also failed under the race detector.
- `git diff --check d4f8700 8ee27b0` passed.
- Hosted Selected qualification has not run. No Mac runner, live model, full performance rerun, normal-install or prior-release qualification, exact-peak measurement, or native fork-safety stress test ran here. Those limits remain explicit. No active measurement orb was used.

Standards axis: two actionable findings, R4 and R5. Spec axis: three actionable findings, R1, R2, and R3. The strongest issue on the Spec axis is the false-success oracle. The Standards axis has dynamically reproduced races and overstated PSS snapshot semantics. The owner must validate and fix the findings before qualification proceeds.
