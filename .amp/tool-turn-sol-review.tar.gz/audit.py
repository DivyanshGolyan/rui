import gzip
import hashlib
import json
import pathlib
import statistics
import subprocess
import tarfile

root = pathlib.Path(__file__).resolve().parent
evidence = root / "evidence/.amp"
counts = {}
for campaign in ("tool-turn", "tool-turn-v2"):
    directory = root / "audit" / campaign
    directory.mkdir(parents=True, exist_ok=True)
    files = sorted((evidence / campaign / "runs").glob("*.json.gz"))
    stats = []
    for file in files:
        label = file.name.removesuffix(".json.gz")
        run = json.loads(gzip.decompress(file.read_bytes()))
        assert run["status"] == "passed", (label, run.get("error"))
        n = run["sessions"]
        provider = run["provider"]
        assert (provider["requests"], provider["done"], provider["succeeded_calls"], provider["failed_calls"]) == (3*n, n, 2*n-1, 0), label
        points = {p["name"]: p for p in run["points"]}
        begin, end = points["before_submit"]["unix_ns"], points["active_end"]["unix_ns"]
        for fact in provider["session_facts"]:
            assert fact["seed_received_unix_ns"] < begin
            assert begin <= fact["measured_received_unix_ns"] <= end
            assert begin <= fact["continuation_received_unix_ns"] <= end
        assert {r["bytes"] for r in run["seed"]["rows"]} == {409600}
        dest = directory / label
        dest.mkdir(exist_ok=True)
        with tarfile.open(file.with_name(label + "-artifacts.tar.gz")) as archive:
            for member in archive:
                if not member.isfile():
                    continue
                path = dest / member.name
                assert path.resolve().is_relative_to(dest.resolve())
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(archive.extractfile(member).read())
        samples = [json.loads(line) for line in (dest / "tree-samples.jsonl").read_text().splitlines()]
        for sample in samples:
            pss, count = sample["pss_bytes"], sample["counts"]
            assert sum(pss.get(c, 0) for c in ("host", "bash", "clients")) == pss.get("total", 0), (label, sample)
            assert sum(count.get(c, 0) for c in ("host", "bash", "clients")) == count.get("total", 0)
        peak = max((s for s in samples if s["phase"] == "active"), key=lambda s: s["pss_bytes"].get("total", 0))
        records = run["process_tree"]["processes"]
        ids = [(r["pid"], r["start_ticks"]) for r in records]
        assert len(ids) == len(set(ids)), label
        run["artifacts"] = str(dest)
        (directory / (label + ".json")).write_text(json.dumps(run))
        stats.append({"label": label, "peak_MB": peak["pss_bytes"]["total"]/1e6,
                      "peak_scan_ms": (peak["end_unix_ns"]-peak["begin_unix_ns"])/1e6,
                      "max_scan_ms": max((s["end_unix_ns"]-s["begin_unix_ns"])/1e6 for s in samples if s["phase"] == "active"),
                      "pss_failures": sum(s["pss_failures"] for s in samples),
                      "worker_failure_example": run.get("dispatch_result_example"),
                      "barrier": run.get("barrier_release")})
    out = root / (campaign + "-reduced.json")
    subprocess.run(["python3", str(evidence / "tool-turn-v2/reduce.py"), str(directory), str(out)], check=True)
    published = json.loads((evidence / "tool-turn-v2" / ("summary-v2.json" if campaign.endswith("v2") else "summary-v1-rereduced.json")).read_text())
    assert json.loads(out.read_text()) == published, campaign
    counts[campaign] = {"runs": len(files), "stats": stats}
(root / "raw-audit.json").write_text(json.dumps(counts, indent=2))
print("All 60 runs: counts, request phases, seed sizes, PSS sums and PID/start identity uniqueness verified; both published reductions reproduced exactly")
for campaign, rows in counts.items():
    for row in rows["stats"]:
        if "read-n100" in row["label"] and "strace" not in row["label"]:
            print(campaign, row)
