package main

import (
	"bytes"
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"

	"rui.local/qualification/measurement"
	"rui.local/qualification/model-output/provider"
)

func main() {
	directory, err := os.MkdirTemp("", "tool-review-probe-")
	if err != nil { panic(err) }
	defer os.RemoveAll(directory)
	readFile := filepath.Join(directory, "read")
	if err := os.WriteFile(readFile, []byte("READ_WITHOUT_RELEASE\n"), 0600); err != nil { panic(err) }
	config := provider.ToolConfig{Sessions: 1, Workload: "read", ReadFile: readFile, DispatchDir: directory, Workspace: "/workspace", Store: "/store", ArtifactDir: directory, Barrier: directory}
	server, err := provider.StartTool(config)
	if err != nil { panic(err) }
	defer server.Close()
	ca, err := os.ReadFile(server.ProviderCAFile())
	if err != nil { panic(err) }
	pool := x509.NewCertPool()
	pool.AppendCertsFromPEM(ca)
	client := &http.Client{Transport: &http.Transport{TLSClientConfig: &tls.Config{RootCAs: pool}, ForceAttemptHTTP2: true}}
	send := func(input []any) string {
		body, _ := json.Marshal(map[string]any{"instructions": measurement.ModelInstructions("/workspace", "/store", provider.ToolSession(1, 0)), "input": input})
		response, err := client.Post(server.ProviderURL(), "application/json", bytes.NewReader(body))
		if err != nil { panic(err) }
		defer response.Body.Close()
		data, _ := io.ReadAll(response.Body)
		if response.StatusCode != 200 { panic(string(data)) }
		return string(data)
	}
	user := map[string]any{"role": "user", "content": "seed"}
	send([]any{user})
	payload := send([]any{user})
	var command string
	for _, line := range strings.Split(payload, "\n") {
		if !strings.HasPrefix(line, "data: {") { continue }
		var event struct { Type string; Item struct { Arguments string } }
		json.Unmarshal([]byte(strings.TrimPrefix(line, "data: ")), &event)
		if event.Type == "response.output_item.done" {
			var args struct { Cmd string }
			json.Unmarshal([]byte(event.Item.Arguments), &args)
			command = args.Cmd
		}
	}
	// Use a short timeout, preserving the exact generated failure control flow.
	command = strings.Replace(command, "-t 120", "-t 0.05", 1)
	if err := syscall.Mkfifo(filepath.Join(directory, "release"), 0600); err != nil { panic(err) }
	output, commandErr := exec.Command("bash", "-c", command).CombinedOutput()
	fmt.Printf("barrier read failure: command_error=%v, output=%q\n", commandErr, output)
	send([]any{user, map[string]any{"type": "function_call_output", "call_id": "tool-000-never-issued", "output": "Bash succeeded. Exit code: 0."}})
	encoded, _ := json.Marshal(server.Snapshot(true))
	fmt.Printf("unissued output accepted: %s\n", encoded)
}
